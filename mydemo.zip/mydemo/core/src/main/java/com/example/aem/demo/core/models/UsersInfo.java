package com.example.aem.demo.core.models;

import java.util.List;
import java.util.Map;

public interface UsersInfo {
    public List<Map<String, String>> getUsersList();

}
