package com.example.aem.demo.core.models;

import java.util.List;
import java.util.Map;

public interface UserProfile {
    public String getFirstName();
    public String getLastName();
    public Integer getAge();
    
}
