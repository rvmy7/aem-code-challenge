package com.example.aem.demo.core.models;

public interface AddUser {
    public String getActionType();
}
