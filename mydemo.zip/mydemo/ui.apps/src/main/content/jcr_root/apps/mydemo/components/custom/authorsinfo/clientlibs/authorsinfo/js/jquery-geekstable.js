$(function () {
    $('.geeks-table').DataTable({
        responsive: true
    });
});